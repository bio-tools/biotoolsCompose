To open this PROPHETS project, you need to install the PROPHETS version of jABC first. The installer can be downloaded from http://prophets.cs.tu-dortmund.de (requires a recent version of Java on your machine).

Launch jABC and add this project via "Project" -> "New Project" and then selecting this directory (e.g. the unzipped "prophets-project.zip"). It will then appear in the project explorer on the left. 

In its "workflows" subdirectory you find files for use cases #1-#4 that constitute the staring points for synthesis execution. They consist of two workflow building blocks (called "SIBs" in jABC) that define the desired workflow's inputs and outputs. If you click on the loosely specified branch (the red arrow) between the blocks, and then on the "Edit branch constraints" button just above the canvas, you can see (and edit) the constraints defined for the respective use case. To start the synthesis, also select the branch and click on the "Directly synthesis this branch" botton located above the canvas as well. A series of pop-up windows will then guide you through the synthesis process. 

Before starting to synthesize, you might want to ensure that you use the same settings as we did for the study described in the manuscript. Go to "Plugins" -> "PROPHETS" -> "Plugin Configuration" and select the following: 
- Default Synthesis Process: pipelining
- Debug Mode: on
- Remove Permutations: no
- Goal Constraint: simple
- Synthesis Algorithm: tsmyoo
- Search Strategy: bounded

Further information on the configuration options can be found at https://jabc.cs.tu-dortmund.de/manual/index.php/PROPHETS_Configuration, general documentation about PROPHETS is available at https://jabc.cs.tu-dortmund.de/manual/index.php/PROPHETS 